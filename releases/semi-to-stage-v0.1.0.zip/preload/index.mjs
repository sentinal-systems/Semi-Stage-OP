import { contextBridge, ipcRenderer } from "electron";
contextBridge.exposeInMainWorld("semiToStage", {
  host: "electron",
  platform: process.platform,
  onShowProof: (cb) => {
    ipcRenderer.on("show:proof", (_e, s) => cb(s));
  },
  saveShow: (json) => ipcRenderer.invoke("show:save", json),
  openShow: () => ipcRenderer.invoke("show:open"),
  exportText: (text, name) => ipcRenderer.invoke("show:export", text, name)
});
