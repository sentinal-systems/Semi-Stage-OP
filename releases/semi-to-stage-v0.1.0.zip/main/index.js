import electron from "electron";
import { join } from "path";
import { writeFileSync, readFileSync } from "fs";
const VOLTS = 230;
const SQRT3 = Math.sqrt(3);
const SUPPLIES = [
  { id: "1p16", name: "1-phase 16A", phases: 1, amps: 16 },
  { id: "1p32", name: "1-phase 32A", phases: 1, amps: 32 },
  { id: "3p16", name: "3-phase 16A", phases: 3, amps: 16 },
  { id: "3p32", name: "3-phase 32A", phases: 3, amps: 32 },
  { id: "3p63", name: "3-phase 63A", phases: 3, amps: 63 },
  { id: "3p125", name: "3-phase 125A", phases: 3, amps: 125 }
];
const TRUCK_CLASSES = [
  { id: "swb", name: "SWB van", lMm: 3200, wMm: 1800, hMm: 1800, payloadKg: 1200, legal: "B licence — no restriction" },
  { id: "luton", name: "Luton 7.5t", lMm: 6100, wMm: 2440, hMm: 2300, payloadKg: 3500, legal: "C1 licence req. (pre-97 B covers it)" },
  { id: "rigid", name: "Rigid 18t", lMm: 7300, wMm: 2440, hMm: 2600, payloadKg: 9e3, legal: "C licence, 18t GVW" },
  { id: "semi", name: "Semi tautliner", lMm: 13600, wMm: 2440, hMm: 2600, payloadKg: 24e3, legal: "C+E licence, 44t GVW artic" }
];
let seq = 0;
const item = (name, kind, w, d, h, weightKg, powerW, qty = 1) => ({ id: `it${++seq}`, name, kind, wMm: w, dMm: d, hMm: h, weightKg, powerW, qty });
function createShow(seed = {}) {
  return {
    id: seed.id ?? "show-1",
    name: seed.name ?? "Untitled Show",
    items: seed.items ?? [],
    trucks: seed.trucks ?? [TRUCK_CLASSES.find((t) => t.id === "semi")],
    crew: seed.crew ?? [],
    schedule: seed.schedule ?? [],
    cables: seed.cables ?? [],
    // painted runs: {id,kind,points:[{x,y}],label}
    venue: seed.venue ?? {
      name: "TBA",
      // venue geometry — declared dims, editable per-show
      wMm: 24e3,
      hMm: 16e3,
      stage: { xMm: 5e3, yMm: 300, wMm: 14e3, dMm: 8e3, hMm: 1200 },
      // hMm = deck height — understage clearance
      // real venues expose multiple feeds — declared positions
      supplies: [
        { pos: "SR", supply: SUPPLIES.find((s) => s.id === "3p63") },
        { pos: "SL", supply: SUPPLIES.find((s) => s.id === "3p63") }
      ]
    }
  };
}
let cseq = 0;
const crewMember = (name, role, dept, callMin) => ({ id: `cr${++cseq}`, name, role, dept, callMin });
const event = (tMin, label, dept = "PM", notes = "") => ({ tMin, label, dept, notes });
function defaultSchedule(loadInMin = 8 * 60) {
  return [
    event(loadInMin, "Load-in — trucks dock", "STAGE"),
    event(loadInMin + 30, "Trunk roll + unpack", "STAGE"),
    event(loadInMin + 60, "Rig — truss + motors", "STAGE"),
    event(loadInMin + 180, "Hang PA + focus LX", "LX"),
    event(loadInMin + 240, "Patch + line check", "AUDIO"),
    event(loadInMin + 330, "Soundcheck", "AUDIO"),
    event(loadInMin + 420, "Doors", "PM"),
    event(loadInMin + 480, "Show", "PM"),
    event(loadInMin + 660, "Load-out", "STAGE")
  ];
}
function sampleShow() {
  const show = createShow({
    name: "DEMO — Riverside Festival, main stage",
    trucks: [
      TRUCK_CLASSES.find((t) => t.id === "semi"),
      TRUCK_CLASSES.find((t) => t.id === "rigid")
    ],
    venue: {
      name: "Riverside Arena",
      wMm: 24e3,
      hMm: 16e3,
      stage: { xMm: 5e3, yMm: 300, wMm: 14e3, dMm: 8e3, hMm: 1200 },
      supplies: [
        { pos: "SR", supply: SUPPLIES.find((s) => s.id === "3p125") },
        { pos: "SL", supply: SUPPLIES.find((s) => s.id === "3p125") },
        { pos: "FOH", supply: SUPPLIES.find((s) => s.id === "3p32") }
      ]
    },
    // the PCO half — crew + run-of-show on the same dataset
    crew: [
      crewMember("H. Sou", "Production Manager", "PM", 0),
      crewMember("LX Chief", "Lighting Crew Chief", "LX", 0),
      crewMember("A1", "FOH Engineer", "AUDIO", 60),
      crewMember("A2", "Monitor Engineer", "AUDIO", 60),
      crewMember("Stage Hands ×4", "Local crew", "STAGE", 0),
      crewMember("Rigger", "Up-rigger", "STAGE", 0),
      crewMember("Lamp Op", "LX Operator", "LX", 240)
    ],
    schedule: defaultSchedule(8 * 60),
    // load-in 08:00
    items: [
      item("Main PA hang L", "speaker", 1200, 800, 1200, 340, 0, 1),
      item("Main PA hang R", "speaker", 1200, 800, 1200, 340, 0, 1),
      item("Subs (stacked pair)", "speaker", 1200, 800, 800, 190, 0, 4),
      item("Amp racks", "case", 600, 800, 900, 95, 0, 6),
      item("FOH console", "desk", 1600, 700, 1100, 85, 420, 1),
      item("Mon desk", "desk", 1200, 600, 900, 60, 300, 1),
      item("Moving heads (pairs cased)", "light", 800, 600, 700, 68, 1150, 12),
      item("LED washes x6 cased", "light", 1e3, 500, 600, 54, 960, 8),
      item("Truss 3m sections", "truss", 3e3, 450, 450, 38, 0, 6),
      item("Truss base + motors", "case", 1e3, 1e3, 800, 120, 2200, 4),
      item("Power distro 125A", "distro", 700, 500, 600, 45, 0, 2),
      item("Cable trunks", "trunk", 1200, 600, 600, 70, 0, 6),
      item("Stage decks 2x1m", "deck", 2e3, 1e3, 100, 42, 0, 8),
      item("D&B wedges x4 cased", "speaker", 900, 500, 500, 46, 0, 4),
      item("Backline cases", "case", 800, 600, 800, 55, 1800, 5),
      item("Runner/cable ramp pack", "trunk", 1e3, 500, 400, 35, 0, 6)
    ]
  });
  const p = (name, x, y) => {
    const it = show.items.find((i) => i.name === name);
    if (it) {
      it.plotX = x;
      it.plotY = y;
    }
  };
  p("Main PA hang L", 4971, 7445);
  p("Main PA hang R", 17792, 7481);
  p("FOH console", 11191, 12818);
  p("Mon desk", 19637, 6938);
  const units = (name, pts) => {
    const it = show.items.find((i) => i.name === name);
    if (it) {
      it.plotUnits = pts.map(([x, y]) => ({ x, y }));
      it.plotX = pts[0][0];
      it.plotY = pts[0][1];
    }
  };
  units("Subs (stacked pair)", [[7369, 7445], [9712, 7481], [13069, 7481], [15541, 7517]]);
  units("Amp racks", [[19051, 6123], [19051, 5337], [19051, 4516], [20767, 6159], [20767, 5337], [20767, 4516]]);
  const tune = (name, t) => Object.assign(show.items.find((i) => i.name === name) ?? {}, t);
  tune("Main PA hang L", { mount: "hung", heightM: 8, aimDeg: 15, lw: 132, horizAngle: 80, pattern: "cone" });
  tune("Main PA hang R", { mount: "hung", heightM: 8, aimDeg: -15, lw: 132, horizAngle: 80, pattern: "cone" });
  tune("Subs (stacked pair)", { mount: "stacked", heightM: 0.5, aimDeg: 0, lw: 136, horizAngle: 360, pattern: "cardioid" });
  tune("D&B wedges x4 cased", { mount: "stacked", heightM: 0.5, aimDeg: -30, lw: 120, horizAngle: 60, pattern: "cone" });
  return show;
}
function recommendVehicles(unpacked) {
  if (!unpacked.length) return [];
  const kg = unpacked.reduce((s, u) => s + (u.weightKg ?? 0), 0);
  const m2 = unpacked.reduce((s, u) => s + u.areaM2, 0);
  const recs = [];
  let kgLeft = kg, m2Left = m2;
  for (let guard = 0; guard < 6 && (kgLeft > 0 || m2Left > 0); guard++) {
    const cls = TRUCK_CLASSES.find(
      (t) => kgLeft <= t.payloadKg && m2Left <= t.lMm * t.wMm / 1e6
    ) ?? TRUCK_CLASSES[TRUCK_CLASSES.length - 1];
    recs.push({ class: cls.name, legal: cls.legal, coversKg: Math.min(kgLeft, cls.payloadKg) });
    kgLeft -= cls.payloadKg;
    m2Left -= cls.lMm * cls.wMm / 1e6;
  }
  return recs;
}
function packShow(show) {
  const trucks = show.trucks.map((t) => ({
    ...t,
    usedAreaM2: 0,
    usedKg: 0,
    loaded: [],
    capacityM2: t.lMm * t.wMm / 1e6
  }));
  const units = [];
  for (const it of show.items) {
    const areaM2 = it.wMm * it.dMm / 1e6;
    for (let q = 0; q < (it.qty ?? 1); q++) {
      units.push({ ...it, areaM2 });
    }
  }
  units.sort((a, b) => b.areaM2 - a.areaM2);
  const unpacked = [];
  for (const u of units) {
    const t = trucks.find(
      (tr) => tr.usedAreaM2 + u.areaM2 <= tr.capacityM2 && tr.usedKg + (u.weightKg ?? 0) <= tr.payloadKg
    );
    if (!t) {
      unpacked.push(u);
      continue;
    }
    t.usedAreaM2 += u.areaM2;
    t.usedKg += u.weightKg ?? 0;
    t.loaded.push(u);
  }
  for (const t of trucks) {
    const wPct = t.usedKg / t.payloadKg;
    const aPct = t.usedAreaM2 / t.capacityM2;
    t.binding = wPct >= 0.95 && aPct < 0.95 ? "payload-capped" : aPct >= 0.95 && wPct < 0.95 ? "floor-capped" : wPct >= 0.95 && aPct >= 0.95 ? "both-capped" : "ok";
  }
  return {
    trucks: trucks.map((t) => ({
      id: t.id,
      name: t.name,
      lMm: t.lMm,
      wMm: t.wMm,
      hMm: t.hMm,
      // dims ride through — layoutTruck + views need them
      usedAreaM2: t.usedAreaM2,
      capacityM2: t.capacityM2,
      usedKg: t.usedKg,
      payloadKg: t.payloadKg,
      areaPct: Math.round(t.usedAreaM2 / t.capacityM2 * 100),
      weightPct: Math.round(t.usedKg / t.payloadKg * 100),
      binding: t.binding,
      loaded: t.loaded,
      loadOrder: [...t.loaded].reverse()
      // last-in first-out at venue
    })),
    unpacked,
    recommendations: recommendVehicles(unpacked),
    warnings: [
      ...unpacked.length ? [`${unpacked.length} item(s) did not fit any truck — see hire recommendation`] : [],
      ...trucks.filter((t) => t.usedKg / t.payloadKg > 0.85).map((t) => `${t.name}: payload ${Math.round(t.usedKg / t.payloadKg * 100)}% — check axle weights`)
    ],
    honest: "2D floor-area + payload only — no stacking, CG or axle calc"
  };
}
const GENNY_HEADROOM = 0.8;
const PF = 0.9;
function powerPlan(show, opts = {}) {
  const totalW = show.items.reduce((s, it) => s + (it.powerW ?? 0) * (it.qty ?? 1), 0);
  const crest = opts.crest ?? 1.3;
  const designW = totalW * crest;
  const gennyKva = designW / PF / GENNY_HEADROOM / 1e3;
  const supplies = show.venue.supplies ?? [];
  const warnings = [];
  const n = supplies.length || 1;
  const feeds = supplies.map((f) => {
    const s = f.supply;
    const assignedW = show.items.filter((it) => it.feedPos === f.pos).reduce((sum, it) => sum + (it.powerW ?? 0) * (it.qty ?? 1), 0) * crest;
    return { pos: f.pos, name: s.name, phases: s.phases, capacityA: s.amps, assignedW };
  });
  const assignedTotal = feeds.reduce((s, f) => s + f.assignedW, 0);
  const unassignedW = designW - assignedTotal;
  feeds.forEach((f) => {
    const shareW = unassignedW / n;
    const feedW = f.assignedW + shareW;
    f.loadW = feedW;
    f.amps = f.phases === 3 ? feedW / (SQRT3 * VOLTS) : feedW / VOLTS;
    f.util = f.amps / f.capacityA;
    if (f.util > 1) warnings.push(`${f.pos}: ${f.amps.toFixed(0)}A on ${f.capacityA}A feed — OVER`);
    else if (f.util > 0.8) warnings.push(`${f.pos}: ${(f.util * 100).toFixed(0)}% — tight`);
  });
  const anyAssigned = assignedTotal > 0;
  if (anyAssigned) warnings.push(`${(unassignedW / 1e3).toFixed(1)}kW unassigned — split evenly across feeds`);
  if (!supplies.length) warnings.push("no venue supplies declared");
  if (totalW === 0) warnings.push("no powered items in the show");
  const capacityA = feeds.reduce((s, f) => s + f.capacityA, 0);
  const demandA = designW / (SQRT3 * VOLTS);
  return {
    totalW,
    designW,
    crest,
    gennyKvaNeeded: gennyKva,
    feeds,
    demandA,
    capacityA,
    anyAssigned,
    warnings,
    honest: "balanced-phase planning estimate — assigned loads honoured, unassigned split evenly; not cable/protection design"
  };
}
const { app, BrowserWindow, dialog, ipcMain } = electron;
ipcMain.handle("show:save", async (_e, json) => {
  const r = await dialog.showSaveDialog({ filters: [{ name: "Show file", extensions: ["show.json", "json"] }] });
  if (r.canceled || !r.filePath) return null;
  writeFileSync(r.filePath, json, "utf8");
  return r.filePath;
});
ipcMain.handle("show:open", async () => {
  const r = await dialog.showOpenDialog({ filters: [{ name: "Show file", extensions: ["json"] }], properties: ["openFile"] });
  if (r.canceled || !r.filePaths[0]) return null;
  return readFileSync(r.filePaths[0], "utf8");
});
ipcMain.handle("show:export", async (_e, text, name) => {
  const r = await dialog.showSaveDialog({ defaultPath: name, filters: [{ name: "Markdown", extensions: ["md", "txt"] }] });
  if (r.canceled || !r.filePath) return null;
  writeFileSync(r.filePath, text, "utf8");
  return r.filePath;
});
app.commandLine.appendSwitch("enable-unsafe-swiftshader");
app.commandLine.appendSwitch("ignore-gpu-blocklist");
app.whenReady().then(() => {
  const win = new BrowserWindow({
    width: 1360,
    height: 860,
    title: "Semi to Stage",
    backgroundColor: "#0a0d12",
    webPreferences: {
      preload: join(import.meta.dirname, "../preload/index.mjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });
  win.maximize();
  win.webContents.on("render-process-gone", (_e, d) => console.error("RENDER GONE:", JSON.stringify(d)));
  win.webContents.on("unresponsive", () => console.error("RENDERER UNRESPONSIVE"));
  const show = sampleShow();
  const pack = packShow(show);
  const power = powerPlan(show);
  setTimeout(() => {
    win.webContents.send("show:proof", {
      trucks: pack.trucks.length,
      loaded: pack.trucks.reduce((s, t) => s + t.loaded.length, 0),
      amps: Math.round(power.demandA)
    });
  }, 1500);
  if (process.env["ELECTRON_RENDERER_URL"]) {
    win.loadURL(process.env["ELECTRON_RENDERER_URL"]);
  } else {
    win.loadFile(join(import.meta.dirname, "../renderer/index.html"));
  }
});
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
